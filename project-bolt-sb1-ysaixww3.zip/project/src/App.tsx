import { useState, useEffect } from 'react';
import { Menu, X, Phone, Mail, Instagram, MapPin, Scale, Shield, FileText, ChevronDown, ArrowUp, CheckCircle, ClipboardList, Target } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [formStatus, setFormStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('success');
    setTimeout(() => setFormStatus('idle'), 5000);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header / Navigation */}
      <header className="fixed top-0 left-0 right-0 bg-[#1a365d] text-white z-50 shadow-lg">
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Scale className="w-8 h-8 text-[#d4af37]" />
              <span className="text-xl font-bold font-['Playfair_Display']">Yuri Fernando Advocacia</span>
            </div>

            {/* Desktop Menu */}
            <ul className="hidden md:flex space-x-8 font-['Montserrat']">
              <li><button onClick={() => scrollToSection('home')} className="hover:text-[#d4af37] transition">Home</button></li>
              <li><button onClick={() => scrollToSection('sobre')} className="hover:text-[#d4af37] transition">Sobre Nós</button></li>
              <li><button onClick={() => scrollToSection('servicos')} className="hover:text-[#d4af37] transition">Serviços</button></li>
              <li><button onClick={() => scrollToSection('depoimentos')} className="hover:text-[#d4af37] transition">Depoimentos</button></li>
              <li><button onClick={() => scrollToSection('perguntas')} className="hover:text-[#d4af37] transition">Perguntas</button></li>
              <li><button onClick={() => scrollToSection('contato')} className="hover:text-[#d4af37] transition">Contato</button></li>
            </ul>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <ul className="md:hidden mt-4 space-y-4 font-['Montserrat']">
              <li><button onClick={() => scrollToSection('home')} className="block hover:text-[#d4af37] transition">Home</button></li>
              <li><button onClick={() => scrollToSection('sobre')} className="block hover:text-[#d4af37] transition">Sobre Nós</button></li>
              <li><button onClick={() => scrollToSection('servicos')} className="block hover:text-[#d4af37] transition">Serviços</button></li>
              <li><button onClick={() => scrollToSection('depoimentos')} className="block hover:text-[#d4af37] transition">Depoimentos</button></li>
              <li><button onClick={() => scrollToSection('perguntas')} className="block hover:text-[#d4af37] transition">Perguntas</button></li>
              <li><button onClick={() => scrollToSection('contato')} className="block hover:text-[#d4af37] transition">Contato</button></li>
            </ul>
          )}
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-16 relative text-white overflow-hidden" style={{background: 'linear-gradient(135deg, rgba(26, 54, 93, 0.9) 0%, rgba(0, 0, 0, 0.8) 100%)'}}>
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 font-['Playfair_Display'] leading-tight">
              Seu tratamento adequado garantido
            </h1>
            <p className="text-xl md:text-2xl mb-10 font-['Montserrat'] leading-relaxed opacity-90">
              Especialista em reverter a negativas de planos de saúde para tratamento de autismo e cirurgias reparadoras. Atuamos para garantir o acesso à saúde que você merece.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/5582991512494"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#d4af37] hover:bg-[#f5d742] text-[#1a365d] font-bold py-4 px-8 rounded-lg transition text-lg font-['Montserrat'] shadow-lg"
              >
                Fale Conosco
              </a>
              <button
                onClick={() => scrollToSection('servicos')}
                className="bg-transparent border-2 border-white hover:bg-white hover:text-[#1a365d] font-bold py-4 px-8 rounded-lg transition text-lg font-['Montserrat']"
              >
                Nossos Serviços
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Sobre Nós Section */}
      <section id="sobre" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-12 text-[#1a365d] font-['Playfair_Display']">
              Sobre Nós
            </h2>
            <div className="bg-white rounded-lg shadow-xl p-8 md:p-12">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-shrink-0">
                  <div className="w-48 h-48 md:w-56 md:h-56 rounded-lg overflow-hidden shadow-2xl">
                    <img
                      src="https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=600"
                      alt="Dr. Yuri Fernando - Advogado especializado em Direito da Saúde"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="text-3xl font-bold text-[#1a365d] mb-4 font-['Playfair_Display']">Dr. Yuri Fernando</h3>
                  <p className="text-lg text-gray-700 mb-4 font-['Montserrat'] leading-relaxed">
                    Advogado especializado em Direito da Saúde, com vasta experiência em reverter negativas de planos de saúde e garantir o acesso a tratamentos essenciais.
                  </p>
                  <p className="text-lg text-gray-700 mb-4 font-['Montserrat'] leading-relaxed">
                    Atuando principalmente em casos de tratamento de autismo e cirurgias reparadoras, conquistamos resultados expressivos para nossos clientes.
                  </p>
                  <div className="flex flex-col gap-2 text-gray-600 font-['Montserrat']">
                    <p className="flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-[#d4af37]" />
                      <span>Arapiraca, Alagoas</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Scale className="w-5 h-5 text-[#d4af37]" />
                      <span>OAB/AL 19.985</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Serviços Section */}
      <section id="servicos" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
            Nossos Serviços
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg font-['Montserrat']">
            Soluções jurídicas especializadas para garantir seus direitos
          </p>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Serviço 1 */}
            <div className="bg-gradient-to-br from-[#1a365d] to-[#2c5282] rounded-lg p-8 text-white shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-[10px]">
              <div className="bg-[#d4af37] w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Shield className="w-8 h-8 text-[#1a365d]" />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-['Playfair_Display']">
                Negativas de Planos de Saúde
              </h3>
              <p className="text-gray-100 font-['Montserrat'] leading-relaxed mb-4">
                Reversão de negativas de cobertura para tratamentos essenciais.
              </p>
              <ul className="space-y-2 font-['Montserrat'] text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Tratamento de autismo</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Cirurgias reparadoras</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Medicamentos de alto custo</span>
                </li>
              </ul>
            </div>

            {/* Serviço 2 */}
            <div className="bg-gradient-to-br from-[#1a365d] to-[#2c5282] rounded-lg p-8 text-white shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-[10px]">
              <div className="bg-[#d4af37] w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Scale className="w-8 h-8 text-[#1a365d]" />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-['Playfair_Display']">
                Ações Judiciais em Saúde
              </h3>
              <p className="text-gray-100 font-['Montserrat'] leading-relaxed mb-4">
                Representação judicial completa para garantir seus direitos.
              </p>
              <ul className="space-y-2 font-['Montserrat'] text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Procedimentos de urgência</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Internações hospitalares</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Terapias especializadas</span>
                </li>
              </ul>
            </div>

            {/* Serviço 3 */}
            <div className="bg-gradient-to-br from-[#1a365d] to-[#2c5282] rounded-lg p-8 text-white shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-[10px]">
              <div className="bg-[#d4af37] w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <FileText className="w-8 h-8 text-[#1a365d]" />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-['Playfair_Display']">
                Assessoria Preventiva
              </h3>
              <p className="text-gray-100 font-['Montserrat'] leading-relaxed mb-4">
                Orientação jurídica preventiva para evitar problemas.
              </p>
              <ul className="space-y-2 font-['Montserrat'] text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Análise de contratos</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Revisão de negativas</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  <span>Estratégias de ação</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona Nosso Atendimento Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
            Como Funciona Nosso Atendimento
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg font-['Montserrat']">
            Um processo transparente e eficiente para garantir seus direitos
          </p>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Passo 1 */}
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition">
              <div className="bg-[#1a365d] w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                <ClipboardList className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-2xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
                Análise do Caso
              </h3>
              <p className="text-gray-700 font-['Montserrat'] leading-relaxed text-center">
                Avaliamos detalhadamente sua situação para entender todas as nuances do seu caso.
              </p>
            </div>

            {/* Passo 2 */}
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition">
              <div className="bg-[#1a365d] w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                <FileText className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-2xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
                Documentação
              </h3>
              <p className="text-gray-700 font-['Montserrat'] leading-relaxed text-center">
                Coletamos toda a documentação necessária para embasar nossa atuação jurídica.
              </p>
            </div>

            {/* Passo 3 */}
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition">
              <div className="bg-[#1a365d] w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                <Target className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-2xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
                Ação Estratégica
              </h3>
              <p className="text-gray-700 font-['Montserrat'] leading-relaxed text-center">
                Definimos a melhor estratégia para garantir seus direitos de forma rápida e eficiente.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos Section */}
      <section id="depoimentos" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
            Depoimentos de Clientes
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg font-['Montserrat']">
            O que nossos clientes dizem sobre nosso trabalho
          </p>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Depoimento 1 */}
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition border-2 border-gray-100">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#1a365d] flex items-center justify-center text-white font-bold font-['Montserrat']">
                  MS
                </div>
                <div className="ml-4">
                  <p className="font-bold text-[#1a365d] font-['Montserrat']">Maria S.</p>
                  <div className="flex text-[#f5d742]">★★★★★</div>
                </div>
              </div>
              <p className="text-gray-700 font-['Montserrat'] leading-relaxed">
                "O Dr. Yuri conseguiu a aprovação do tratamento do meu filho autista que o plano de saúde vinha negando há meses."
              </p>
            </div>

            {/* Depoimento 2 */}
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition border-2 border-gray-100">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#1a365d] flex items-center justify-center text-white font-bold font-['Montserrat']">
                  JP
                </div>
                <div className="ml-4">
                  <p className="font-bold text-[#1a365d] font-['Montserrat']">João P.</p>
                  <div className="flex text-[#f5d742]">★★★★★</div>
                </div>
              </div>
              <p className="text-gray-700 font-['Montserrat'] leading-relaxed">
                "Após várias tentativas frustradas, o Dr. Yuri garantiu minha cirurgia reparadora que o plano se recusava a cobrir."
              </p>
            </div>

            {/* Depoimento 3 */}
            <div className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition border-2 border-gray-100">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#1a365d] flex items-center justify-center text-white font-bold font-['Montserrat']">
                  AL
                </div>
                <div className="ml-4">
                  <p className="font-bold text-[#1a365d] font-['Montserrat']">Ana L.</p>
                  <div className="flex text-[#f5d742]">★★★★★</div>
                </div>
              </div>
              <p className="text-gray-700 font-['Montserrat'] leading-relaxed">
                "Excelente profissional! Resolveu meu caso de medicamento de alto custo em tempo recorde."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="perguntas" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-[#1a365d] font-['Playfair_Display']">
            Perguntas Frequentes
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg font-['Montserrat']">
            Tire suas dúvidas sobre direito à saúde
          </p>

          <div className="max-w-3xl mx-auto space-y-4">
            {/* FAQ 1 */}
            <div className="bg-white rounded-lg overflow-hidden shadow">
              <button
                onClick={() => toggleFaq(0)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <span className="font-bold text-[#1a365d] font-['Montserrat'] text-lg pr-4">
                  O plano de saúde pode negar qualquer tratamento?
                </span>
                <ChevronDown className={`w-6 h-6 text-[#1a365d] transition-transform flex-shrink-0 ${openFaq === 0 ? 'rotate-180' : ''}`} />
              </button>
              {openFaq === 0 && (
                <div className="p-6 pt-0 text-gray-700 font-['Montserrat'] leading-relaxed">
                  Não. Os planos de saúde não podem negar tratamentos prescritos por médicos, especialmente quando há cobertura contratual e previsão na ANS. Negativas abusivas podem e devem ser questionadas judicialmente.
                </div>
              )}
            </div>

            {/* FAQ 2 */}
            <div className="bg-white rounded-lg overflow-hidden shadow">
              <button
                onClick={() => toggleFaq(1)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <span className="font-bold text-[#1a365d] font-['Montserrat'] text-lg pr-4">
                  Quanto tempo demora para resolver um caso de negativa de tratamento?
                </span>
                <ChevronDown className={`w-6 h-6 text-[#1a365d] transition-transform flex-shrink-0 ${openFaq === 1 ? 'rotate-180' : ''}`} />
              </button>
              {openFaq === 1 && (
                <div className="p-6 pt-0 text-gray-700 font-['Montserrat'] leading-relaxed">
                  Em casos urgentes, podemos obter liminares em 24 a 48 horas. Para casos regulares, o processo pode levar de 30 a 90 dias, dependendo da complexidade e da urgência do tratamento.
                </div>
              )}
            </div>

            {/* FAQ 3 */}
            <div className="bg-white rounded-lg overflow-hidden shadow">
              <button
                onClick={() => toggleFaq(2)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <span className="font-bold text-[#1a365d] font-['Montserrat'] text-lg pr-4">
                  Quais documentos são necessários para entrar com uma ação contra o plano de saúde?
                </span>
                <ChevronDown className={`w-6 h-6 text-[#1a365d] transition-transform flex-shrink-0 ${openFaq === 2 ? 'rotate-180' : ''}`} />
              </button>
              {openFaq === 2 && (
                <div className="p-6 pt-0 text-gray-700 font-['Montserrat'] leading-relaxed">
                  Geralmente são necessários: contrato do plano de saúde, prescrição médica detalhada, carta de negativa do plano, documentos pessoais e histórico médico. Cada caso pode requerer documentação específica adicional.
                </div>
              )}
            </div>

            {/* FAQ 4 */}
            <div className="bg-white rounded-lg overflow-hidden shadow">
              <button
                onClick={() => toggleFaq(3)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <span className="font-bold text-[#1a365d] font-['Montserrat'] text-lg pr-4">
                  O que fazer se o plano de saúde negar o tratamento para autismo?
                </span>
                <ChevronDown className={`w-6 h-6 text-[#1a365d] transition-transform flex-shrink-0 ${openFaq === 3 ? 'rotate-180' : ''}`} />
              </button>
              {openFaq === 3 && (
                <div className="p-6 pt-0 text-gray-700 font-['Montserrat'] leading-relaxed">
                  Entre em contato imediatamente com um advogado especializado. Tratamentos para autismo têm amparo legal e as negativas são frequentemente abusivas. Podemos buscar liminares urgentes para garantir o tratamento.
                </div>
              )}
            </div>

            {/* FAQ 5 */}
            <div className="bg-white rounded-lg overflow-hidden shadow">
              <button
                onClick={() => toggleFaq(4)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <span className="font-bold text-[#1a365d] font-['Montserrat'] text-lg pr-4">
                  Posso processar o plano de saúde sozinho?
                </span>
                <ChevronDown className={`w-6 h-6 text-[#1a365d] transition-transform flex-shrink-0 ${openFaq === 4 ? 'rotate-180' : ''}`} />
              </button>
              {openFaq === 4 && (
                <div className="p-6 pt-0 text-gray-700 font-['Montserrat'] leading-relaxed">
                  Embora seja possível, não é recomendado. O direito da saúde é complexo e requer conhecimento técnico específico. Um advogado especializado aumenta significativamente suas chances de sucesso e agiliza o processo.
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Contato Section */}
      <section id="contato" className="py-20 bg-gradient-to-br from-[#1a365d] via-[#2c5282] to-[#1a365d] text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 font-['Playfair_Display']">
            Entre em Contato
          </h2>
          <p className="text-center text-gray-100 mb-12 text-lg font-['Montserrat']">
            Estamos prontos para defender seus direitos
          </p>

          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12">
            {/* Informações de Contato */}
            <div>
              <h3 className="text-2xl font-bold mb-6 font-['Playfair_Display']">
                Informações de Contato
              </h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-bold font-['Montserrat'] mb-1">Endereço</p>
                    <p className="text-gray-100 font-['Montserrat']">
                      Rua Professor Domingos Correia, n° 177<br />
                      Centro, Arapiraca – AL
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-bold font-['Montserrat'] mb-1">Telefone / WhatsApp</p>
                    <a href="tel:+5582991512494" className="text-gray-100 hover:text-[#f5d742] transition font-['Montserrat']">
                      (82) 99151-2494
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-bold font-['Montserrat'] mb-1">E-mail</p>
                    <a href="mailto:yuriifernando.adv@gmail.com" className="text-gray-100 hover:text-[#f5d742] transition font-['Montserrat']">
                      yuriifernando.adv@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Instagram className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-bold font-['Montserrat'] mb-1">Instagram</p>
                    <a
                      href="https://instagram.com/yurifernando.adv"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-100 hover:text-[#f5d742] transition font-['Montserrat']"
                    >
                      @yurifernando.adv
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Formulário de Contato */}
            <div>
              <h3 className="text-2xl font-bold mb-6 font-['Playfair_Display']">
                Envie uma Mensagem
              </h3>
              <form className="space-y-4" onSubmit={handleSubmit}>
                <div>
                  <label className="block mb-2 font-['Montserrat'] font-medium">Nome Completo</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white text-gray-900 font-['Montserrat'] focus:outline-none focus:ring-2 focus:ring-[#d4af37]"
                    placeholder="Seu nome completo"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-['Montserrat'] font-medium">E-mail</label>
                  <input
                    type="email"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white text-gray-900 font-['Montserrat'] focus:outline-none focus:ring-2 focus:ring-[#d4af37]"
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-['Montserrat'] font-medium">Telefone</label>
                  <input
                    type="tel"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white text-gray-900 font-['Montserrat'] focus:outline-none focus:ring-2 focus:ring-[#d4af37]"
                    placeholder="(00) 00000-0000"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-['Montserrat'] font-medium">Mensagem</label>
                  <textarea
                    rows={4}
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white text-gray-900 font-['Montserrat'] focus:outline-none focus:ring-2 focus:ring-[#d4af37]"
                    placeholder="Descreva brevemente seu caso..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#d4af37] hover:bg-[#f5d742] text-[#1a365d] font-bold py-4 px-8 rounded-lg transition font-['Montserrat'] shadow-lg"
                >
                  Enviar Mensagem
                </button>

                {formStatus === 'success' && (
                  <div className="bg-green-500 text-white p-4 rounded-lg font-['Montserrat'] text-center">
                    Mensagem enviada com sucesso! Entraremos em contato em breve.
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Logo e Info */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-12 h-12 bg-[#d4af37] rounded-full flex items-center justify-center">
                  <span className="text-[#1a365d] font-bold text-xl font-['Playfair_Display']">YF</span>
                </div>
                <span className="text-lg font-bold font-['Playfair_Display']">Yuri Fernando Advocacia</span>
              </div>
              <p className="text-gray-400 font-['Montserrat'] text-sm">
                Especialistas em Direito da Saúde
              </p>
              <p className="text-gray-400 font-['Montserrat'] text-sm mt-2">
                OAB/AL n° 19.985
              </p>
            </div>

            {/* Links Rápidos */}
            <div>
              <h4 className="font-bold mb-4 font-['Playfair_Display'] text-lg">Links Rápidos</h4>
              <ul className="space-y-2 font-['Montserrat'] text-sm">
                <li>
                  <button onClick={() => scrollToSection('home')} className="text-gray-400 hover:text-[#d4af37] transition">
                    Home
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('sobre')} className="text-gray-400 hover:text-[#d4af37] transition">
                    Sobre Nós
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('servicos')} className="text-gray-400 hover:text-[#d4af37] transition">
                    Serviços
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('depoimentos')} className="text-gray-400 hover:text-[#d4af37] transition">
                    Depoimentos
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('contato')} className="text-gray-400 hover:text-[#d4af37] transition">
                    Contato
                  </button>
                </li>
              </ul>
            </div>

            {/* Redes Sociais */}
            <div>
              <h4 className="font-bold mb-4 font-['Playfair_Display'] text-lg">Redes Sociais</h4>
              <div className="flex gap-4">
                <a
                  href="https://wa.me/5582991512494"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-[#1a365d] rounded-full flex items-center justify-center hover:bg-[#d4af37] transition"
                >
                  <Phone className="w-5 h-5" />
                </a>
                <a
                  href="https://instagram.com/yurifernando.adv"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-[#1a365d] rounded-full flex items-center justify-center hover:bg-[#d4af37] transition"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="mailto:yuriifernando.adv@gmail.com"
                  className="w-10 h-10 bg-[#1a365d] rounded-full flex items-center justify-center hover:bg-[#d4af37] transition"
                >
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 font-['Montserrat'] text-sm">
              © 2023 Yuri Fernando Advocacia. Todos os direitos reservados. OAB/AL n° 19.985
            </p>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 bg-[#d4af37] hover:bg-[#f5d742] text-[#1a365d] p-4 rounded-full shadow-lg transition transform hover:scale-110 z-40"
          aria-label="Voltar ao topo"
        >
          <ArrowUp className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}

export default App;
